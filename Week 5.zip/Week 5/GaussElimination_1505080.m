%1505080 Offline 2 B1 Gauss Elimination Script

A = [1, -1, 1
    3, 4, 2
    2, 1, 1] ;

B =[6
   9
   7] ;
 

X = Gauss(A,B)
%3,-1,2

C = [1, 1, 2 , 0
    2, -1, 0, 1
    1, -1 ,-1, -2
    2, -1, 2, -1]

D = [1
    -2
    4
    0]

X = Gauss(C,D)
%1,2,-1,-2


